
-- -----------------------------------------------------
-- Table `medlonode_DEVICE`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS medlonode_DEVICE (
  medlonode_DEVICE_ID VARCHAR(45) NOT NULL ,
  DEVICE_NAME VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (medlonode_DEVICE_ID) );

